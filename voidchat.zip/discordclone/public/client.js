/**
 * client.js — VoidChat Frontend Logic
 * Весь клиентский код: авторизация, WebSocket, рендеринг интерфейса
 */

// ─────────────────────────────────────────────
// Глобальное состояние
// ─────────────────────────────────────────────
const State = {
  user: null,           // { id, username, token }
  ws: null,             // WebSocket соединение
  currentChannel: null, // { id, name, type: 'channel' | 'dm' }
  currentServerId: null,
  servers: [],
  friends: [],
  onlineUsers: new Set(),
  typingTimers: {},
};

// ─────────────────────────────────────────────
// Utils
// ─────────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
};

const avatarLetter = (name) => (name || '?')[0].toUpperCase();
const timeStr = (dt) => {
  const d = new Date(dt);
  return d.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
};
const dateTimeStr = (dt) => {
  const d = new Date(dt);
  return d.toLocaleDateString('ru') + ' ' + d.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
};

// ─────────────────────────────────────────────
// API helper
// ─────────────────────────────────────────────
async function api(method, url, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (State.user?.token) opts.headers['Authorization'] = State.user.token;
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Ошибка');
  return data;
}

// ─────────────────────────────────────────────
// Хранение сессии в localStorage
// ─────────────────────────────────────────────
function saveSession(user) {
  localStorage.setItem('vc_user', JSON.stringify(user));
}
function loadSession() {
  try { return JSON.parse(localStorage.getItem('vc_user')); } catch { return null; }
}
function clearSession() {
  localStorage.removeItem('vc_user');
}

// ─────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────
function showAuth() {
  $('#auth-screen').style.display = 'flex';
  $('#app').style.display = 'none';
}

function showApp() {
  $('#auth-screen').style.display = 'none';
  $('#app').style.display = 'flex';
}

function showAuthError(msg) {
  const e = $('#auth-error');
  e.textContent = msg;
  e.style.display = 'block';
  setTimeout(() => e.style.display = 'none', 4000);
}

// Переключение табов авторизации
document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    $('#tab-login').style.display = tab.dataset.tab === 'login' ? 'flex' : 'none';
    $('#tab-register').style.display = tab.dataset.tab === 'register' ? 'flex' : 'none';
    $('#auth-error').style.display = 'none';
  });
});

$('#btn-login').addEventListener('click', async () => {
  const username = $('#login-username').value.trim();
  const password = $('#login-password').value;
  if (!username || !password) return showAuthError('Заполните все поля');
  try {
    const user = await api('POST', '/api/login', { username, password });
    State.user = user;
    saveSession(user);
    initApp();
  } catch (e) { showAuthError(e.message); }
});

$('#btn-register').addEventListener('click', async () => {
  const username = $('#reg-username').value.trim();
  const password = $('#reg-password').value;
  if (!username || !password) return showAuthError('Заполните все поля');
  try {
    const user = await api('POST', '/api/register', { username, password });
    State.user = user;
    saveSession(user);
    initApp();
  } catch (e) { showAuthError(e.message); }
});

// Enter для входа
$('#login-password').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btn-login').click(); });
$('#reg-password').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btn-register').click(); });

// ─────────────────────────────────────────────
// WebSocket
// ─────────────────────────────────────────────
function connectWS() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(`${proto}://${location.host}`);
  State.ws = ws;

  ws.onopen = () => {
    ws.send(JSON.stringify({ type: 'auth', userId: State.user.id, token: State.user.token }));
  };

  ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    handleWSMessage(msg);
  };

  ws.onclose = () => {
    // Переподключение через 3 секунды
    setTimeout(connectWS, 3000);
  };
}

function wsSend(data) {
  if (State.ws && State.ws.readyState === WebSocket.OPEN) {
    State.ws.send(JSON.stringify(data));
  }
}

function handleWSMessage(msg) {
  switch (msg.type) {
    case 'channel_message':
      if (State.currentChannel?.id === msg.message.channelId) {
        appendMessage(msg.message, 'channel');
      }
      break;

    case 'dm_message': {
      const dm = msg.message;
      const otherId = dm.fromId === State.user.id ? dm.toId : dm.fromId;
      if (State.currentChannel?.type === 'dm' && State.currentChannel?.id === otherId) {
        appendMessage(dm, 'dm');
      }
      break;
    }

    case 'user_status':
      if (msg.isOnline) State.onlineUsers.add(msg.userId);
      else State.onlineUsers.delete(msg.userId);
      refreshMembersPanel();
      refreshDMList();
      break;

    case 'typing':
      showTyping(msg.channelId, msg.username);
      break;
  }
}

// ─────────────────────────────────────────────
// Инициализация приложения
// ─────────────────────────────────────────────
async function initApp() {
  showApp();
  // Показать аватар пользователя
  const myAvatar = $('#my-avatar-btn');
  myAvatar.textContent = avatarLetter(State.user.username);
  myAvatar.title = State.user.username;

  connectWS();
  await loadServers();
  await loadFriends();
  showDMsSidebar();
}

// ─────────────────────────────────────────────
// Серверы
// ─────────────────────────────────────────────
async function loadServers() {
  State.servers = await api('GET', '/api/servers');
  renderServerList();
}

function renderServerList() {
  const container = $('#servers-container');
  container.innerHTML = '';
  State.servers.forEach(s => {
    const icon = el('div', 'server-icon');
    icon.textContent = s.name[0].toUpperCase();
    icon.title = s.name;
    const tooltip = el('span', 'tooltip', s.name);
    icon.appendChild(tooltip);
    icon.addEventListener('click', () => selectServer(s.id));
    if (State.currentServerId === s.id) icon.classList.add('active');
    container.appendChild(icon);
  });
}

async function selectServer(serverId) {
  State.currentServerId = serverId;
  // Подсветить активный сервер
  document.querySelectorAll('#servers-container .server-icon').forEach(el => el.classList.remove('active'));
  const icons = document.querySelectorAll('#servers-container .server-icon');
  const idx = State.servers.findIndex(s => s.id === serverId);
  if (icons[idx]) icons[idx].classList.add('active');

  try {
    const server = await api('GET', `/api/servers/${serverId}`);
    renderChannelsSidebar(server);
    renderMembersPanel(server.members);
    $('#sidebar-title').textContent = server.name;
    $('#btn-add-friend').style.display = 'none';
    $('#btn-add-channel').style.display = '';

    // Показать кнопку "Покинуть" (не для владельца)
    const isOwner = server.ownerId === State.user.id;
    $('#btn-leave-server').style.display = isOwner ? 'none' : '';
    $('#btn-leave-server').onclick = () => leaveServer(serverId);
    $('#btn-invite-user').style.display = '';
    $('#btn-invite-user').onclick = () => showInviteModal(serverId);

    // Показать ID сервера
    $('#chat-server-id-display').style.display = '';
    $('#chat-server-id-display').textContent = `ID: ${serverId.slice(0,8)}...`;

  } catch (e) {
    console.error(e);
  }
}

function renderChannelsSidebar(server) {
  const list = $('#channel-list');
  list.innerHTML = '';
  const header = el('div', 'channel-section-header', 'Текстовые каналы');
  list.appendChild(header);

  server.channels.forEach(ch => {
    const item = el('div', 'channel-item');
    item.innerHTML = `<span class="channel-hash">#</span><span>${ch.name}</span>`;

    // Кнопка удаления канала (только для владельца)
    if (server.ownerId === State.user.id) {
      const delBtn = el('button', 'channel-delete-btn', '✕');
      delBtn.title = 'Удалить канал';
      delBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (confirm(`Удалить канал #${ch.name}?`)) {
          await api('DELETE', `/api/channels/${ch.id}`);
          await selectServer(server.id);
        }
      });
      item.appendChild(delBtn);
    }

    item.addEventListener('click', () => openChannel(ch.id, ch.name, server.id));
    list.appendChild(item);
  });
}

async function openChannel(channelId, name, serverId) {
  // Подсветить активный канал
  document.querySelectorAll('.channel-item').forEach(e => e.classList.remove('active'));
  event?.currentTarget?.classList.add('active');

  State.currentChannel = { id: channelId, type: 'channel', name };
  $('#chat-title').textContent = `# ${name}`;
  $('#message-input').disabled = false;
  $('#message-input').placeholder = `Сообщение в #${name}`;
  $('#btn-send').disabled = false;

  const messages = await api('GET', `/api/channels/${channelId}/messages`);
  renderMessages(messages, 'channel');
}

// Создание сервера
$('#btn-create-server').addEventListener('click', () => {
  showModal('Создать сервер', `
    <input class="modal-input" id="m-server-name" placeholder="Название сервера" />
    <div class="modal-error" id="m-err"></div>
    <button class="modal-btn" id="m-create-server">Создать</button>
  `);
  setTimeout(() => {
    $('#m-create-server').addEventListener('click', async () => {
      const name = $('#m-server-name').value.trim();
      if (!name) return;
      try {
        const server = await api('POST', '/api/servers', { name });
        State.servers.push(server);
        renderServerList();
        hideModal();
        await selectServer(server.id);
      } catch (e) {
        const err = $('#m-err');
        err.textContent = e.message;
        err.style.display = 'block';
      }
    });
    $('#m-server-name').addEventListener('keydown', e => { if (e.key === 'Enter') $('#m-create-server').click(); });
    $('#m-server-name').focus();
  }, 50);
});

// Вступить по ID сервера
$('#btn-join-server').addEventListener('click', () => {
  showModal('Вступить на сервер', `
    <p class="text-muted text-sm">Попросите владельца сервера поделиться его ID (8 символов после "ID:")</p>
    <input class="modal-input" id="m-server-id" placeholder="ID сервера (полный)" />
    <div class="modal-error" id="m-err"></div>
    <div class="modal-success" id="m-ok">Вы вступили на сервер!</div>
    <button class="modal-btn" id="m-join-btn">Вступить</button>
  `);
  setTimeout(() => {
    $('#m-join-btn').addEventListener('click', async () => {
      const sid = $('#m-server-id').value.trim();
      if (!sid) return;
      try {
        await api('POST', `/api/servers/${sid}/join`);
        const server = await api('GET', `/api/servers/${sid}`);
        State.servers.push(server);
        renderServerList();
        const ok = $('#m-ok');
        ok.style.display = 'block';
        setTimeout(hideModal, 1200);
        selectServer(sid);
      } catch (e) {
        const err = $('#m-err');
        err.textContent = e.message;
        err.style.display = 'block';
      }
    });
    $('#m-server-id').focus();
  }, 50);
});

// Покинуть сервер
async function leaveServer(serverId) {
  if (!confirm('Покинуть сервер?')) return;
  await api('DELETE', `/api/servers/${serverId}/leave`);
  State.servers = State.servers.filter(s => s.id !== serverId);
  State.currentServerId = null;
  State.currentChannel = null;
  renderServerList();
  showDMsSidebar();
  $('#messages-area').innerHTML = '<div class="welcome-message"><div class="welcome-icon">💬</div><h2>Вы покинули сервер</h2></div>';
  $('#btn-leave-server').style.display = 'none';
  $('#btn-invite-user').style.display = 'none';
  $('#chat-server-id-display').style.display = 'none';
}

// Добавить участника на сервер (по нику)
function showInviteModal(serverId) {
  showModal('Пригласить участника', `
    <p class="text-muted text-sm">Поделитесь ID сервера с другом, чтобы он мог вступить:</p>
    <div class="modal-input" style="cursor:text;user-select:all;font-family:monospace;font-size:13px">${serverId}</div>
    <p class="text-muted text-sm">Друг должен нажать «Вступить по ID» и вставить этот ID.</p>
  `);
}

// Создать канал (из sidebar-header)
$('#btn-add-channel').addEventListener('click', () => {
  if (!State.currentServerId) return;
  showModal('Создать канал', `
    <input class="modal-input" id="m-ch-name" placeholder="название-канала" />
    <div class="modal-error" id="m-err"></div>
    <button class="modal-btn" id="m-create-ch">Создать</button>
  `);
  setTimeout(() => {
    $('#m-create-ch').addEventListener('click', async () => {
      const name = $('#m-ch-name').value.trim();
      if (!name) return;
      try {
        await api('POST', `/api/servers/${State.currentServerId}/channels`, { name });
        hideModal();
        await selectServer(State.currentServerId);
      } catch (e) {
        const err = $('#m-err');
        err.textContent = e.message;
        err.style.display = 'block';
      }
    });
    $('#m-ch-name').addEventListener('keydown', e => { if (e.key === 'Enter') $('#m-create-ch').click(); });
    $('#m-ch-name').focus();
  }, 50);
});

// ─────────────────────────────────────────────
// Личные сообщения и Друзья
// ─────────────────────────────────────────────

// Показать DM-боковую панель (при нажатии на иконку)
$('#btn-dms').addEventListener('click', () => {
  State.currentServerId = null;
  document.querySelectorAll('#servers-container .server-icon').forEach(e => e.classList.remove('active'));
  $('#btn-leave-server').style.display = 'none';
  $('#btn-invite-user').style.display = 'none';
  $('#chat-server-id-display').style.display = 'none';
  showDMsSidebar();
});

function showDMsSidebar() {
  $('#sidebar-title').textContent = 'Личные сообщения';
  $('#btn-add-friend').style.display = '';
  $('#btn-add-channel').style.display = 'none';
  renderDMList();
  renderMembersPanel([]);
}

async function loadFriends() {
  State.friends = await api('GET', '/api/friends');
}

function renderDMList() {
  const list = $('#channel-list');
  list.innerHTML = '';

  const header = el('div', 'dm-section-label', 'Друзья');
  list.appendChild(header);

  if (State.friends.length === 0) {
    const empty = el('div', 'text-muted text-sm', 'Нет друзей. Добавьте первого!');
    empty.style.padding = '8px 10px';
    list.appendChild(empty);
    return;
  }

  State.friends.forEach(f => {
    const item = el('div', 'dm-item');
    const isOnline = State.onlineUsers.has(f.friendId);
    item.innerHTML = `
      <div class="dm-avatar">${avatarLetter(f.username)}<span class="${isOnline ? 'online-dot' : 'online-dot offline-dot'}"></span></div>
      <span>${f.username}</span>
    `;
    item.addEventListener('click', () => openDM(f.friendId, f.username));
    if (State.currentChannel?.type === 'dm' && State.currentChannel?.id === f.friendId) {
      item.classList.add('active');
    }
    list.appendChild(item);
  });
}

function refreshDMList() {
  if ($('#sidebar-title').textContent === 'Личные сообщения') {
    renderDMList();
  }
}

async function openDM(userId, username) {
  document.querySelectorAll('.dm-item').forEach(e => e.classList.remove('active'));
  State.currentChannel = { id: userId, type: 'dm', name: username };
  $('#chat-title').textContent = `@ ${username}`;
  $('#message-input').disabled = false;
  $('#message-input').placeholder = `Сообщение для ${username}`;
  $('#btn-send').disabled = false;

  const messages = await api('GET', `/api/dm/${userId}`);
  renderMessages(messages, 'dm');
  renderDMList();
}

// Добавить друга
$('#btn-add-friend').addEventListener('click', () => {
  showModal('Управление друзьями', `
    <div style="display:flex;gap:8px">
      <input class="modal-input" id="m-friend-name" placeholder="Имя пользователя" style="flex:1" />
      <button class="modal-btn" id="m-add-friend-btn" style="white-space:nowrap">Добавить</button>
    </div>
    <div class="modal-error" id="m-err"></div>
    <div class="modal-success" id="m-ok"></div>
    <div id="m-friends-list"></div>
  `);
  setTimeout(() => {
    renderModalFriends();
    $('#m-add-friend-btn').addEventListener('click', async () => {
      const username = $('#m-friend-name').value.trim();
      if (!username) return;
      try {
        await api('POST', '/api/friends/add', { username });
        await loadFriends();
        renderModalFriends();
        const ok = $('#m-ok');
        ok.textContent = `${username} добавлен(а) в друзья!`;
        ok.style.display = 'block';
        setTimeout(() => ok.style.display = 'none', 2000);
        $('#m-friend-name').value = '';
        renderDMList();
      } catch (e) {
        const err = $('#m-err');
        err.textContent = e.message;
        err.style.display = 'block';
        setTimeout(() => err.style.display = 'none', 3000);
      }
    });
    $('#m-friend-name').addEventListener('keydown', e => { if (e.key === 'Enter') $('#m-add-friend-btn').click(); });
    $('#m-friend-name').focus();
  }, 50);
});

function renderModalFriends() {
  const container = $('#m-friends-list');
  if (!container) return;
  container.innerHTML = '';
  if (State.friends.length === 0) {
    container.innerHTML = '<div class="text-muted text-sm" style="padding:8px 0">Список друзей пуст</div>';
    return;
  }
  State.friends.forEach(f => {
    const item = el('div', 'friend-item');
    item.innerHTML = `
      <div class="dm-avatar">${avatarLetter(f.username)}</div>
      <span class="fa">${f.username}</span>
      <button class="btn-dm" data-id="${f.friendId}">💬 Написать</button>
      <button data-id="${f.friendId}">Удалить</button>
    `;
    item.querySelectorAll('button')[0].addEventListener('click', () => {
      hideModal();
      openDM(f.friendId, f.username);
    });
    item.querySelectorAll('button')[1].addEventListener('click', async () => {
      await api('DELETE', `/api/friends/${f.friendId}`);
      await loadFriends();
      renderModalFriends();
      renderDMList();
    });
    container.appendChild(item);
  });
}

// ─────────────────────────────────────────────
// Сообщения
// ─────────────────────────────────────────────
let lastMsgAuthor = null;
let lastMsgTime = null;

function renderMessages(messages, type) {
  const area = $('#messages-area');
  area.innerHTML = '';
  lastMsgAuthor = null;
  lastMsgTime = null;

  if (messages.length === 0) {
    const empty = el('div', 'welcome-message');
    empty.innerHTML = `<div class="welcome-icon">🗨️</div><h2>Начало истории</h2><p>Здесь пока нет сообщений. Напишите первое!</p>`;
    area.appendChild(empty);
    return;
  }

  messages.forEach(m => appendMessageEl(m, type, false));
  area.scrollTop = area.scrollHeight;
}

function appendMessage(m, type) {
  appendMessageEl(m, type, true);
}

function appendMessageEl(m, type, scroll) {
  const area = $('#messages-area');

  // Убрать welcome если есть
  const welcome = area.querySelector('.welcome-message');
  if (welcome) welcome.remove();

  const author = type === 'dm' ? m.fromUsername : m.username;
  const msgTime = new Date(m.createdAt).getTime();
  const isGrouped = author === lastMsgAuthor && msgTime - lastMsgTime < 5 * 60 * 1000;

  const msg = el('div', `message${isGrouped ? ' grouped' : ''}`);
  const avatarDiv = el('div', 'message-avatar', avatarLetter(author));
  const body = el('div', 'message-body');

  if (!isGrouped) {
    const header = el('div', 'message-header');
    header.innerHTML = `<span class="message-author">${escapeHtml(author)}</span><span class="message-timestamp">${dateTimeStr(m.createdAt)}</span>`;
    body.appendChild(header);
  }

  const content = el('div', 'message-content', escapeHtml(m.content));
  body.appendChild(content);

  msg.appendChild(avatarDiv);
  msg.appendChild(body);
  area.appendChild(msg);

  lastMsgAuthor = author;
  lastMsgTime = msgTime;

  if (scroll) area.scrollTop = area.scrollHeight;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─────────────────────────────────────────────
// Отправка сообщений
// ─────────────────────────────────────────────
$('#btn-send').addEventListener('click', sendMessage);
$('#message-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
  // Сигнал о печати
  if (State.currentChannel?.type === 'channel') {
    wsSend({ type: 'typing', channelId: State.currentChannel.id });
  }
});

function sendMessage() {
  const input = $('#message-input');
  const content = input.value.trim();
  if (!content || !State.currentChannel) return;
  input.value = '';

  if (State.currentChannel.type === 'channel') {
    wsSend({ type: 'channel_message', channelId: State.currentChannel.id, content });
  } else if (State.currentChannel.type === 'dm') {
    wsSend({ type: 'dm_message', toUserId: State.currentChannel.id, content });
  }
}

// ─────────────────────────────────────────────
// Typing indicator
// ─────────────────────────────────────────────
function showTyping(channelId, username) {
  if (!State.currentChannel || State.currentChannel.id !== channelId) return;
  const indicator = $('#typing-indicator');
  indicator.textContent = `${username} печатает...`;
  clearTimeout(State.typingTimers[username]);
  State.typingTimers[username] = setTimeout(() => {
    indicator.textContent = '';
  }, 3000);
}

// ─────────────────────────────────────────────
// Участники (правая панель)
// ─────────────────────────────────────────────
function renderMembersPanel(members) {
  const list = $('#members-list');
  list.innerHTML = '';
  if (!members || members.length === 0) return;

  const online = members.filter(m => m.isOnline);
  const offline = members.filter(m => !m.isOnline);

  if (online.length > 0) {
    list.appendChild(el('div', 'member-section-header', `Онлайн — ${online.length}`));
    online.forEach(m => list.appendChild(createMemberEl(m, true)));
  }
  if (offline.length > 0) {
    list.appendChild(el('div', 'member-section-header', `Не в сети — ${offline.length}`));
    offline.forEach(m => list.appendChild(createMemberEl(m, false)));
  }
}

function createMemberEl(m, isOnline) {
  const item = el('div', `member-item ${isOnline ? '' : 'offline'}`);
  item.innerHTML = `
    <div class="member-avatar">${avatarLetter(m.username)}<span class="${isOnline ? 'online-dot' : 'online-dot offline-dot'}"></span></div>
    <span class="member-name">${escapeHtml(m.username)}</span>
    ${m.role === 'owner' ? '<span class="member-role">👑</span>' : ''}
  `;
  // Клик по участнику — открыть DM
  item.addEventListener('click', () => {
    if (m.id !== State.user.id) {
      // Проверить что это не мы
      openDMFromMember(m.id, m.username);
    }
  });
  return item;
}

async function openDMFromMember(userId, username) {
  // Убедиться что друг добавлен
  const existing = State.friends.find(f => f.friendId === userId);
  if (!existing) {
    if (confirm(`Добавить ${username} в друзья для начала чата?`)) {
      try {
        await api('POST', '/api/friends/add', { username });
        await loadFriends();
      } catch {}
    } else return;
  }
  State.currentServerId = null;
  document.querySelectorAll('#servers-container .server-icon').forEach(e => e.classList.remove('active'));
  showDMsSidebar();
  setTimeout(() => openDM(userId, username), 100);
}

function refreshMembersPanel() {
  // Обновить только если смотрим на канал сервера
  if (State.currentServerId) {
    api('GET', `/api/servers/${State.currentServerId}`)
      .then(s => renderMembersPanel(s.members))
      .catch(() => {});
  }
}

// ─────────────────────────────────────────────
// Modal helper
// ─────────────────────────────────────────────
function showModal(title, bodyHTML) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHTML;
  $('#modal-overlay').style.display = 'flex';
}

function hideModal() {
  $('#modal-overlay').style.display = 'none';
}

$('#modal-close').addEventListener('click', hideModal);
$('#modal-overlay').addEventListener('click', e => {
  if (e.target === $('#modal-overlay')) hideModal();
});

// ─────────────────────────────────────────────
// Профиль (мой аккаунт)
// ─────────────────────────────────────────────
$('#my-avatar-btn').addEventListener('click', () => {
  showModal('Мой профиль', `
    <div style="display:flex;align-items:center;gap:16px;padding-bottom:12px">
      <div class="member-avatar" style="width:56px;height:56px;font-size:24px">${avatarLetter(State.user.username)}</div>
      <div>
        <div style="font-size:18px;font-weight:700">${escapeHtml(State.user.username)}</div>
        <div class="text-muted text-sm">ID: ${State.user.id.slice(0,8)}...</div>
      </div>
    </div>
    <button class="modal-btn" id="m-logout" style="background:#ed4245">Выйти</button>
  `);
  setTimeout(() => {
    $('#m-logout').addEventListener('click', () => {
      clearSession();
      location.reload();
    });
  }, 50);
});

// ─────────────────────────────────────────────
// Запуск
// ─────────────────────────────────────────────
(function init() {
  const session = loadSession();
  if (session) {
    State.user = session;
    initApp();
  } else {
    showAuth();
  }
})();
