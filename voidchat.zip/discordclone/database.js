/**
 * database.js — Хранилище данных на основе JSON-файлов
 * Работает без нативных зависимостей на любом Node.js хостинге
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');

// Создать папку data если нет
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

// ─────────────────────────────────────────────
// JSON helpers
// ─────────────────────────────────────────────

function dbFile(name) {
  return path.join(DATA_DIR, `${name}.json`);
}

function readList(name) {
  const file = dbFile(name);
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return []; }
}

function writeList(name, data) {
  fs.writeFileSync(dbFile(name), JSON.stringify(data, null, 2), 'utf8');
}

// Инициализация пустых таблиц
['users','servers','server_members','channels','channel_messages','dm_messages','friends']
  .forEach(name => { if (!fs.existsSync(dbFile(name))) writeList(name, []); });

const { v4: uuidv4 } = require('uuid');

// ─────────────────────────────────────────────
// Пользователи
// ─────────────────────────────────────────────
module.exports.createUser = (username, password, token) => {
  const users = readList('users');
  const user = { id: uuidv4(), username, password, token, isOnline: 0, createdAt: new Date().toISOString() };
  users.push(user);
  writeList('users', users);
  return { id: user.id, username: user.username, token: user.token };
};

module.exports.getUserById = (id) =>
  readList('users').find(u => u.id === id) || null;

module.exports.getUserByUsername = (username) =>
  readList('users').find(u => u.username.toLowerCase() === username.toLowerCase()) || null;

module.exports.getUserByToken = (token) =>
  readList('users').find(u => u.token === token) || null;

module.exports.updateToken = (id, token) => {
  const users = readList('users');
  const u = users.find(u => u.id === id);
  if (u) { u.token = token; writeList('users', users); }
};

module.exports.setUserOnline = (id, status) => {
  const users = readList('users');
  const u = users.find(u => u.id === id);
  if (u) { u.isOnline = status; writeList('users', users); }
};

module.exports.searchUsers = (q, excludeId) =>
  readList('users')
    .filter(u => u.id !== excludeId && u.username.toLowerCase().includes(q.toLowerCase()))
    .slice(0, 10)
    .map(u => ({ id: u.id, username: u.username }));

// ─────────────────────────────────────────────
// Серверы
// ─────────────────────────────────────────────
module.exports.createServer = (name, ownerId) => {
  const servers = readList('servers');
  const server = { id: uuidv4(), name, ownerId, createdAt: new Date().toISOString() };
  servers.push(server);
  writeList('servers', servers);
  return server;
};

module.exports.getServerById = (id) =>
  readList('servers').find(s => s.id === id) || null;

module.exports.getUserServers = (userId) => {
  const memberOf = readList('server_members').filter(m => m.userId === userId).map(m => m.serverId);
  return readList('servers').filter(s => memberOf.includes(s.id));
};

module.exports.addServerMember = (serverId, userId, role = 'member') => {
  const members = readList('server_members');
  if (!members.find(m => m.serverId === serverId && m.userId === userId)) {
    members.push({ serverId, userId, role, joinedAt: new Date().toISOString() });
    writeList('server_members', members);
  }
};

module.exports.removeServerMember = (serverId, userId) => {
  writeList('server_members',
    readList('server_members').filter(m => !(m.serverId === serverId && m.userId === userId)));
};

module.exports.isServerMember = (serverId, userId) =>
  !!readList('server_members').find(m => m.serverId === serverId && m.userId === userId);

module.exports.getServerMember = (serverId, userId) =>
  readList('server_members').find(m => m.serverId === serverId && m.userId === userId) || null;

module.exports.getChannelMembers = (channelId) => {
  const channel = readList('channels').find(c => c.id === channelId);
  if (!channel) return [];
  return readList('server_members').filter(m => m.serverId === channel.serverId);
};

module.exports.getServerMembersWithStatus = (serverId, clients) => {
  const members = readList('server_members').filter(m => m.serverId === serverId);
  const users = readList('users');
  return members.map(m => {
    const u = users.find(u => u.id === m.userId);
    if (!u) return null;
    return { id: u.id, username: u.username, role: m.role, isOnline: clients.has(u.id) };
  }).filter(Boolean);
};

// ─────────────────────────────────────────────
// Каналы
// ─────────────────────────────────────────────
module.exports.createChannel = (serverId, name, type = 'text') => {
  const channels = readList('channels');
  const channel = { id: uuidv4(), serverId, name, type, createdAt: new Date().toISOString() };
  channels.push(channel);
  writeList('channels', channels);
  return channel;
};

module.exports.getServerChannels = (serverId) =>
  readList('channels').filter(c => c.serverId === serverId);

module.exports.getChannelById = (id) =>
  readList('channels').find(c => c.id === id) || null;

module.exports.deleteChannel = (id) => {
  writeList('channels', readList('channels').filter(c => c.id !== id));
  writeList('channel_messages', readList('channel_messages').filter(m => m.channelId !== id));
};

// ─────────────────────────────────────────────
// Сообщения каналов
// ─────────────────────────────────────────────
module.exports.createChannelMessage = (userId, channelId, content) => {
  const messages = readList('channel_messages');
  const msg = { id: uuidv4(), channelId, userId, content, createdAt: new Date().toISOString() };
  messages.push(msg);
  writeList('channel_messages', messages);
  return msg;
};

module.exports.getMessageById = (id) => {
  const msg = readList('channel_messages').find(m => m.id === id);
  if (!msg) return null;
  const user = readList('users').find(u => u.id === msg.userId);
  return { ...msg, username: user?.username || 'Unknown' };
};

module.exports.getChannelMessages = (channelId, limit = 50) => {
  const msgs = readList('channel_messages').filter(m => m.channelId === channelId);
  const users = readList('users');
  return msgs.slice(-limit).map(m => ({
    ...m, username: users.find(u => u.id === m.userId)?.username || 'Unknown'
  }));
};

// ─────────────────────────────────────────────
// Личные сообщения
// ─────────────────────────────────────────────
module.exports.createDM = (fromId, toId, content) => {
  const messages = readList('dm_messages');
  const msg = { id: uuidv4(), fromId, toId, content, createdAt: new Date().toISOString() };
  messages.push(msg);
  writeList('dm_messages', messages);
  return msg;
};

module.exports.getDMById = (id) => {
  const msg = readList('dm_messages').find(m => m.id === id);
  if (!msg) return null;
  const user = readList('users').find(u => u.id === msg.fromId);
  return { ...msg, fromUsername: user?.username || 'Unknown' };
};

module.exports.getDMMessages = (userId1, userId2, limit = 50) => {
  const msgs = readList('dm_messages').filter(m =>
    (m.fromId === userId1 && m.toId === userId2) ||
    (m.fromId === userId2 && m.toId === userId1)
  );
  const users = readList('users');
  return msgs.slice(-limit).map(m => ({
    ...m, fromUsername: users.find(u => u.id === m.fromId)?.username || 'Unknown'
  }));
};

// ─────────────────────────────────────────────
// Друзья
// ─────────────────────────────────────────────
module.exports.addFriend = (userId, friendId) => {
  const friends = readList('friends');
  if (!friends.find(f => f.userId === userId && f.friendId === friendId))
    friends.push({ userId, friendId, createdAt: new Date().toISOString() });
  if (!friends.find(f => f.userId === friendId && f.friendId === userId))
    friends.push({ userId: friendId, friendId: userId, createdAt: new Date().toISOString() });
  writeList('friends', friends);
};

module.exports.removeFriend = (userId, friendId) => {
  writeList('friends', readList('friends').filter(f =>
    !(f.userId === userId && f.friendId === friendId) &&
    !(f.userId === friendId && f.friendId === userId)
  ));
};

module.exports.getFriends = (userId) => {
  const users = readList('users');
  return readList('friends')
    .filter(f => f.userId === userId)
    .map(f => {
      const u = users.find(u => u.id === f.friendId);
      return u ? { friendId: u.id, username: u.username } : null;
    }).filter(Boolean);
};

module.exports.getFriendship = (userId, friendId) =>
  readList('friends').find(f => f.userId === userId && f.friendId === friendId) || null;
